const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

interface ProductRequest {
  nome: string;
  link: string;
}

function extractPrice(markdown: string): number | null {
  // Match Brazilian price patterns: R$ 1.234,56 or R$1234,56 or 1.234,56
  const patterns = [
    /R\$\s*([\d.]+,\d{2})/g,
    /(\d{1,3}(?:\.\d{3})*,\d{2})/g,
  ];

  const prices: number[] = [];

  for (const pattern of patterns) {
    let match;
    while ((match = pattern.exec(markdown)) !== null) {
      const priceStr = match[1].replace(/\./g, '').replace(',', '.');
      const price = parseFloat(priceStr);
      if (!isNaN(price) && price > 1 && price < 100000) {
        prices.push(price);
      }
    }
    if (prices.length > 0) break;
  }

  // Return the most common/first reasonable price
  if (prices.length === 0) return null;

  // Often the main price appears first or most frequently
  const freq = new Map<number, number>();
  for (const p of prices) {
    freq.set(p, (freq.get(p) || 0) + 1);
  }

  // Return most frequent, or first if all unique
  let best = prices[0];
  let bestCount = 0;
  for (const [price, count] of freq) {
    if (count > bestCount) {
      best = price;
      bestCount = count;
    }
  }

  return best;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('FIRECRAWL_API_KEY');
    if (!apiKey) {
      return new Response(
        JSON.stringify({ success: false, error: 'FIRECRAWL_API_KEY not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { products } = await req.json() as { products: ProductRequest[] };

    // Filter out Instagram links
    const scrapeable = products.filter(p => !p.link.includes('instagram.com'));
    const results: Record<string, number | null> = {};

    for (const p of products) {
      results[p.nome] = null;
    }

    // Scrape in batches of 3
    const batchSize = 3;
    for (let i = 0; i < scrapeable.length; i += batchSize) {
      const batch = scrapeable.slice(i, i + batchSize);
      const promises = batch.map(async (product) => {
        try {
          console.log(`Scraping: ${product.nome} - ${product.link}`);

          const response = await fetch('https://api.firecrawl.dev/v1/scrape', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${apiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              url: product.link,
              formats: ['markdown'],
              onlyMainContent: true,
              waitFor: 3000,
            }),
          });

          const data = await response.json();

          if (response.ok) {
            const md = data?.data?.markdown || data?.markdown || '';
            console.log(`Markdown length for ${product.nome}: ${md.length}`);

            const price = extractPrice(md);
            if (price) {
              results[product.nome] = price;
              console.log(`Price for ${product.nome}: R$ ${price}`);
            } else {
              console.log(`No price found for ${product.nome}. First 500 chars: ${md.substring(0, 500)}`);
            }
          } else {
            console.log(`Firecrawl error for ${product.nome}: ${response.status} ${JSON.stringify(data)}`);
          }
        } catch (err) {
          console.error(`Error scraping ${product.nome}:`, err);
        }
      });

      await Promise.all(promises);
    }

    return new Response(
      JSON.stringify({ success: true, prices: results }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
