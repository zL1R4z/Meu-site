import { useMemo, useState, useEffect } from "react";
import { produtos, Product } from "@/data/products";
import ProductCard from "@/components/ProductCard";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const [valor, setValor] = useState("");
  const [busca, setBusca] = useState("");
  const [produtosComPreco, setProdutosComPreco] = useState<Product[]>(produtos);
  const [carregando, setCarregando] = useState(false);
  const { toast } = useToast();

  const valorMax = parseFloat(valor);

  useEffect(() => {
    const fetchPrices = async () => {
      setCarregando(true);
      try {
        const { data, error } = await supabase.functions.invoke('scrape-prices', {
          body: {
            products: produtos.map(p => ({ nome: p.nome, link: p.link })),
          },
        });

        if (error) throw error;

        if (data?.success && data.prices) {
          setProdutosComPreco(
            produtos.map(p => ({
              ...p,
              precoAtualizado: data.prices[p.nome] ?? null,
            }))
          );
          toast({
            title: "Preços atualizados!",
            description: "Os preços foram buscados nos sites dos produtos.",
          });
        }
      } catch (err) {
        console.error('Erro ao buscar preços:', err);
        toast({
          title: "Aviso",
          description: "Não foi possível atualizar todos os preços. Mostrando preços de referência.",
          variant: "destructive",
        });
      } finally {
        setCarregando(false);
      }
    };

    fetchPrices();
  }, []);

  const produtosFiltrados = useMemo(() => {
    let lista = produtosComPreco;

    if (busca.trim()) {
      const termo = busca.toLowerCase();
      lista = lista.filter((p) => p.nome.toLowerCase().includes(termo));
    }

    if (valor && !isNaN(valorMax)) {
      lista = lista.filter((p) => {
        const preco = p.precoAtualizado ?? p.preco;
        return preco <= valorMax;
      });
    }

    return lista.sort((a, b) => a.nome.localeCompare(b.nome));
  }, [valor, valorMax, busca, produtosComPreco]);

  const mostrar = busca.trim() || (valor && !isNaN(valorMax));

  return (
    <div className="flex min-h-screen items-start justify-center px-4 py-12">
      <div className="w-full max-w-[700px] rounded-2xl bg-card p-8 text-center shadow-[0_8px_20px_rgba(0,0,0,0.3)]">
        <h1 className="mb-5 text-3xl font-bold text-card-foreground">
          O que me dar de presente?
        </h1>
        <p className="mb-5 text-lg font-medium text-muted-foreground">
          Pesquise por nome ou informe o valor máximo que deseja gastar:
        </p>

        {carregando && (
          <div className="mb-4 flex items-center justify-center gap-2 text-sm text-muted-foreground">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            Atualizando preços em tempo real...
          </div>
        )}

        <div className="mx-auto flex w-full max-w-[400px] flex-col gap-3">
          <input
            type="text"
            placeholder="Pesquisar produto..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="w-full rounded-lg border-2 border-input bg-card px-3 py-3 text-base text-card-foreground outline-none transition-all focus:border-primary focus:shadow-[0_0_5px_hsl(199,29%,45%,0.5)]"
          />
          <input
            type="number"
            placeholder="Valor máximo (Ex.: 500)"
            value={valor}
            onChange={(e) => setValor(e.target.value)}
            className="w-full rounded-lg border-2 border-input bg-card px-3 py-3 text-base text-card-foreground outline-none transition-all focus:border-primary focus:shadow-[0_0_5px_hsl(199,29%,45%,0.5)]"
          />
        </div>

        <div className="mt-8 flex flex-col gap-3">
          {mostrar && produtosFiltrados.length > 0 &&
            produtosFiltrados.map((produto) => (
              <ProductCard key={produto.nome} produto={produto} />
            ))}

          {mostrar && produtosFiltrados.length === 0 && (
            <p className="mt-2 text-base font-medium text-destructive">
              Nenhum produto encontrado.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Index;
