export interface Product {
  nome: string;
  preco: number;
  link: string;
  precoAtualizado?: number | null;
  atualizando?: boolean;
}

export const produtos: Product[] = [
  { nome: "iPhone 16", preco: 4775.99, link: "https://www.amazon.com.br/Apple-iPhone-16-128-GB/dp/B0DJFTJ6LX/ref=sr_1_2?sr=8-2" },
  { nome: "iPhone 16 Pro", preco: 6119.99, link: "https://www.instagram.com/jv_imports_?igsh=ZWQxandqdnF0OWNr" },
  { nome: "iPhone 17", preco: 6667.99, link: "https://www.instagram.com/jv_imports_?igsh=ZWQxandqdnF0OWNr" },
  { nome: "iPhone 17 Pro", preco: 9371.99, link: "https://www.instagram.com/juy_cell?igsh=eXp4azk0dGxmeDN4" },
  { nome: "Tapa Olho", preco: 21.66, link: "https://www.mercadolivre.com.br/p/MLB52127724?pdp_filters=item_id:MLB5710574304&matt_tool=38524122#origin=share&sid=share&wid=MLB5710574304&action=copy" },
  { nome: "Bateria IPhone 11", preco: 399.99, link: "https://www.instagram.com/mymagicstoresousa?igsh=eGRwc3F5eWxhZWYw" },
  { nome: "Mochila 50L", preco: 128.15, link: "https://produto.mercadolivre.com.br/MLB-4136051377?matt_tool=38524122#origin=share&sid=share&action=copy" },
  { nome: "Mochila Executiva Grande", preco: 110.31, link: "https://produto.mercadolivre.com.br/MLB-3898735809?attributes=FABRIC_DESIGN:TGlzbw==,COLOR_SECONDARY_COLOR:UHJldG8=&matt_tool=38524122#origin=share&sid=share&action=copy" },
  { nome: "Mala Viagem", preco: 474.90, link: "https://www.mercadolivre.com.br/up/MLBU2979674904?pdp_filters=item_id:MLB3958702249&matt_tool=38524122#origin=share&sid=share&wid=MLB3958702249&action=copy" },
  { nome: "S24 Ultra", preco: 5498.99, link: "https://www.amazon.com.br/Smartphone-Samsung-Galaxy-Selfie-1-120Hz/dp/B0CQD9VK7X/ref=sr_1_5?sr=8-5" },
  { nome: "S25 Ultra", preco: 6420.99, link: "https://shop.samsung.com/br/galaxy-s25-ultra/p" },
  { nome: "Kit violão", preco: 1993.99, link: "https://www.mercadolivre.com.br/up/MLBU3704300010?pdp_filters=item_id:MLB6100449460&matt_tool=38524122#origin=share&sid=share&wid=MLB6100449460&action=copy" },
  { nome: "Cabo Santo Ângelo", preco: 68.82, link: "https://www.mercadolivre.com.br/p/MLB23157657?pdp_filters=item_id:MLB4057121218&matt_tool=38524122#origin=share&sid=share&wid=MLB4057121218&action=copy" },
  { nome: "Mi Box S Tv Box", preco: 417.09, link: "https://www.mercadolivre.com.br/up/MLBU3439088838?pdp_filters=item_id:MLB5613295472&matt_tool=38524122#origin=share&sid=share&wid=MLB5613295472&action=copy" },
];
