import type { Product } from "@/data/products";

const ProductCard = ({ produto }: { produto: Product }) => {
  const precoExibido = produto.precoAtualizado ?? produto.preco;
  const atualizado = produto.precoAtualizado != null;
  const mudou = atualizado && produto.precoAtualizado !== produto.preco;

  return (
    <div className="rounded-lg bg-muted p-4 text-left shadow-md transition-all hover:shadow-lg hover:-translate-y-0.5">
      <b className="text-lg font-semibold text-primary">{produto.nome}</b>
      <br />
      <span className="text-muted-foreground">
        Preço: R$ {precoExibido.toFixed(2).replace(".", ",")}
        {atualizado && (
          <span className="ml-2 text-xs text-green-600 dark:text-green-400">● atualizado</span>
        )}
        {!atualizado && (
          <span className="ml-2 text-xs text-muted-foreground/60">● referência</span>
        )}
      </span>
      {mudou && (
        <div className="text-xs text-muted-foreground/70 line-through">
          Antes: R$ {produto.preco.toFixed(2).replace(".", ",")}
        </div>
      )}
      <div className="flex justify-end mt-2">
        <a
          href={produto.link}
          target="_blank"
          rel="noopener noreferrer"
          className="font-bold text-destructive transition-colors hover:text-destructive/80 hover:underline"
        >
          Ver oferta
        </a>
      </div>
    </div>
  );
};

export default ProductCard;
